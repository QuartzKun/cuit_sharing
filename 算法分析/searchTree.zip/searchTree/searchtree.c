﻿#include"searchtree.h"

/*以递归的方式传递进行树节点的释放*/
tree MakeEmptyTree(tree root)
{
    if(root != NULL)
    {
        MakeEmptyTree(root->left);
        MakeEmptyTree(root->right);
        free(root);
        root = NULL;
    }
    return root;
}

nodePtr Find(TreeElementType x,tree root)
{
    if(root != NULL)
    {
        if(root->element < x)
        {
            return Find(x,root->right);
        }
        if(root->element > x)
        {
            return Find(x,root->left);
        }
    }
    return root;
}

/*FindMax可以用递归，也可以用迭代
下面通过迭代的方式实现进行最大值的查找
递归的查找的思路如下：
nodeptr FindMax(tree root)
{
    if(root == NULL)
    {
        return NULL;
    }
    if(root->right != NULL)
    {
        return FindMax(root);
    }
    return root;
}
FindMin递归实现同上
*/
nodePtr FindMax(tree root)
{
    if(root == NULL)
    {
        return NULL;
    }
    while((root->right)!= NULL)
    {
        root = root->right;
    }
    return root;
}

nodePtr FindMin(tree root)
{
    if(root == NULL)
    {
        return NULL;
    }
    while((root->left) != NULL)
    {
        root = root->left;
    }
    return root;
}

void SearchTreeInsert(TreeElementType x,tree *root)
{
    if((*root)==NULL)
    {
        (*root) =  (nodePtr) malloc(sizeof(node));

        if((*root) == NULL)
        {
            printf("can't malloc ,insert operation failed");
        }
        (*root)->frequency = 1;
        (*root)->element = x;
        (*root)->left = NULL;
        (*root)->right = NULL;
        return;
    }
    if(x > ((*root)->element))
    {
        SearchTreeInsert(x,&(*root)->right);
        return;
    }
    if(x < ((*root)->element))
    {
        SearchTreeInsert(x,&(*root)->left);
        return;
    }
    if(x == ((*root)->element))
    {
        ++((*root)->frequency);
    }
}


void deleteTreeNode(TreeElementType x,tree *root)
{
    nodePtr targetPtr = NULL;
    nodePtr tmpPtr = NULL;
    nodePtr minPtr = NULL;
    if((*root) == NULL)
    {
        printf("Empty Tree\n");
        return;
    }

    targetPtr = Find(x,*root);
    if(targetPtr == NULL)
    {
        printf("%d is exit in the tree\n",x);
        return;
    }

    if(targetPtr->frequency > 1)
    {
        --targetPtr->frequency;
        return;
    }

    if((targetPtr->left != NULL)&&(targetPtr->right != NULL))
    {
        minPtr = FindMin(targetPtr->right); //最小值肯定没有左子树

        targetPtr->element = minPtr->element;

        if((minPtr->right == NULL))
        {
            tmpPtr = targetPtr;
            if(tmpPtr->right == minPtr) //为左子树的第一个节点
            {
                free(minPtr);
                tmpPtr->left = NULL;
                tmpPtr->right = NULL;
                return;
            }
            tmpPtr = tmpPtr->right;
            while(tmpPtr != NULL)
            {
                if(tmpPtr->left == minPtr)
                {
                    free(minPtr);
                    tmpPtr->left = NULL;
                    return;
                }
                tmpPtr = tmpPtr->left;
            }
        }

        if(minPtr->right != NULL)
        {
            tmpPtr = minPtr->right;
            minPtr->element = tmpPtr->element;
            minPtr->frequency = tmpPtr->frequency;
            minPtr->left = tmpPtr->left;
            minPtr->right = tmpPtr->right;

            free(tmpPtr);
            return;
        }

    }

    if((targetPtr->left != NULL)&&(targetPtr->right == NULL))
    {
        tmpPtr = targetPtr->left;

        targetPtr->element = tmpPtr->element;
        targetPtr->left = tmpPtr->left;
        targetPtr->right = tmpPtr->right;
        targetPtr->frequency = tmpPtr->frequency;

        free(tmpPtr);
        return;
    }

    if((targetPtr->left == NULL)&&(targetPtr->right != NULL))
    {
        tmpPtr = targetPtr->right;

        targetPtr->element = tmpPtr->element;
        targetPtr->left = tmpPtr->left;
        targetPtr->right = tmpPtr->right;
        targetPtr->frequency = tmpPtr->frequency;

        free(tmpPtr);
        return;
    }

    if((targetPtr->left == NULL)&&(targetPtr->right == NULL))
    {
        if((*root) == targetPtr)
        {
            free(targetPtr);
            (*root) = NULL;
            return;
        }
        tmpPtr = *root;   //找到父亲节点
        while(tmpPtr != NULL)
        {
            if(x < tmpPtr->element)
            {
                if(tmpPtr->left == targetPtr) break;
                    else tmpPtr = tmpPtr->left;
            }

            if(x > tmpPtr->element)
            {
                if(tmpPtr->right == targetPtr) break;
                    else tmpPtr = tmpPtr->right;
            }
        }
        free(targetPtr);
        tmpPtr->left = NULL;
        tmpPtr->right = NULL;
        return;
    }
}






