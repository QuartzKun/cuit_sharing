﻿#include <stdio.h>
#include "searchtree.h"
int main(int argc, char *argv[])
{
    int i = 0;
    char a[12] = {10,23,45,2,6,4,8,5,6,22,120,42};

    nodePtr tmpPtr;
    tree t = NULL;

    for(i = 0;i < 12;++i)
    {
        SearchTreeInsert(a[i],&t);
    }

    tmpPtr = FindMax(t);
    if(tmpPtr != NULL)
    {
        printf("Max:%d\n",tmpPtr->element);
    }
    tmpPtr = FindMin(t);
    if(tmpPtr != NULL)
    {
        printf("Min:%d\n",tmpPtr->element);
    }

    tmpPtr = Find(6,t);
    if(tmpPtr != NULL)
    {
        printf("6 frequecy is %d\n",tmpPtr->frequency);
    }

    deleteTreeNode(6,&t);
    tmpPtr = Find(6,t);
    if(tmpPtr != NULL)
    {
        printf("6 frequecy is %d\n",tmpPtr->frequency);
    }

    deleteTreeNode(10,&t);
    tmpPtr = Find(10,t);
    if(tmpPtr == NULL)
    {
        printf("10 don't exit\n");
    }
        else
        {
            printf("10 exit\n");
        }

    printf("root:%d\n",t->element);
    tmpPtr = FindMax(t);
    printf("max:%d\n",tmpPtr->element);
    tmpPtr = FindMin(t);
    printf("min:%d\n",tmpPtr->element);

    deleteTreeNode(2,&t);
    deleteTreeNode(120,&t);

    printf("root:%d\n",t->element);
    tmpPtr = FindMax(t);
    printf("max:%d\n",tmpPtr->element);
    tmpPtr = FindMin(t);
    printf("min:%d\n",tmpPtr->element);


    t = MakeEmptyTree(t);
    if(t == NULL)
    {
        printf("The tree is empty\n");
    }

    return 0;
}
