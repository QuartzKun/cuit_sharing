﻿#ifndef SEARCHTREE_H
#define SEARCHTREE_H
#include<stdlib.h>
#include<stdio.h>
typedef char TreeElementType;
struct TreeNode
{
    TreeElementType element;
    unsigned int frequency;//当有重复的元素的时候的计数
    struct TreeNode *right;
    struct TreeNode *left;
};
typedef struct TreeNode *nodePtr;
typedef struct TreeNode *tree;
typedef struct TreeNode node;

tree MakeEmptyTree(tree root);
nodePtr Find(TreeElementType x,tree root);
nodePtr FindMax(tree root);
nodePtr FindMin(tree root);
void SearchTreeInsert(TreeElementType x,tree *root);
void deleteTreeNode(TreeElementType x,tree *root);
#endif // SEARCHTREE_H
